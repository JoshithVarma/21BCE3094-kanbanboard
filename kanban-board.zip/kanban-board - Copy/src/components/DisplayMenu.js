// src/components/DisplayMenu.js
import React from 'react';
import './DisplayMenu.css';
import downIcon from '../Assets/icons_FEtask/down.svg'; // Import the down icon

const DisplayMenu = ({ grouping, ordering, setGrouping, setOrdering }) => {
    return (
        <div className="DisplayMenu">
            <div className="dropdown">
                <label>
                    Grouping
                    <select value={grouping} onChange={(e) => setGrouping(e.target.value)}>
                        <option value="Status">Status</option>
                        <option value="User">User</option>
                        <option value="Priority">Priority</option>
                    </select>
                    <img src={downIcon} alt="Dropdown arrow" className="dropdown-icon" />
                </label>
            </div>
            <div className="dropdown">
                <label>
                    Ordering
                    <select value={ordering} onChange={(e) => setOrdering(e.target.value)}>
                        <option value="Priority">Priority</option>
                        <option value="Title">Title</option>
                    </select>
                    <img src={downIcon} alt="Dropdown arrow" className="dropdown-icon" />
                </label>
            </div>
        </div>
    );
};

export default DisplayMenu;
