import React from 'react';
import './Column.css';
import Card from './Card';
import urgentPriorityIcon from '../Assets/icons_FEtask/SVG - Urgent Priority colour.svg';
import highPriorityIcon from '../Assets/icons_FEtask/Img - High Priority.svg';
import mediumPriorityIcon from '../Assets/icons_FEtask/Img - Medium Priority.svg';
import lowPriorityIcon from '../Assets/icons_FEtask/Img - Low Priority.svg';
import noPriorityIcon from '../Assets/icons_FEtask/No-priority.svg';
import inProgressIcon from '../Assets/icons_FEtask/in-progress.svg';
import backlogIcon from '../Assets/icons_FEtask/Backlog.svg';
import doneIcon from '../Assets/icons_FEtask/Done.svg';
import cancelledIcon from '../Assets/icons_FEtask/Cancelled.svg';
import todoIcon from '../Assets/icons_FEtask/To-do.svg';
import add from '../Assets/icons_FEtask/add.svg'
import dots from '../Assets/icons_FEtask/3 dot menu.svg'
import Board from './Board';


const Column = ({ title, tickets, ordering, grouping }) => {
    const getPriorityIcon = (priority) => {
        switch (priority) {
            case 4:
                return urgentPriorityIcon;
            case 3:
                return highPriorityIcon;
            case 2:
                return mediumPriorityIcon;
            case 1:
                return lowPriorityIcon;
            default:
                return noPriorityIcon;
        }
    };
    const getStatusIcon = (status) => {
        switch (status) {
            case 'In progress':
                return inProgressIcon;
            case 'Backlog':
                return backlogIcon;
            case 'Done':
                return doneIcon;
            case 'Cancelled':
                return cancelledIcon;
            case 'Todo':
                return todoIcon;
            default:
                return null;
        }
    };
    
    const getIcon = (title) => {
        if (grouping === 'Priority') {
            return getPriorityIcon(Number(title));
        } else {
            return getStatusIcon(title);
        }
    };
    return (
        <div className="column">
            <div className='title-img'>
                <div className='flex'>
            <img src={getIcon(title)} alt={tickets.status} className="status-icon" />
            <h2>{title}({tickets.length})</h2>
            </div>
            <div className='flex'>
            <img src={add} alt="" width={30}/>
            <img src={dots} alt="" width={30}/>
            </div>
            </div>
            <div className="card-container">
                {tickets.map(ticket => (
                    <Card key={ticket.id} ticket={ticket} grouping={grouping} ordering={ordering} />
                ))}
            </div>
        </div>
    );
};

export default Column;
