import React from 'react';
import './Card.css';
import urgentPriorityIcon from '../Assets/icons_FEtask/SVG - Urgent Priority colour.svg';
import highPriorityIcon from '../Assets/icons_FEtask/Img - High Priority.svg';
import mediumPriorityIcon from '../Assets/icons_FEtask/Img - Medium Priority.svg';
import lowPriorityIcon from '../Assets/icons_FEtask/Img - Low Priority.svg';
import noPriorityIcon from '../Assets/icons_FEtask/No-priority.svg';
import inProgressIcon from '../Assets/icons_FEtask/in-progress.svg';
import backlogIcon from '../Assets/icons_FEtask/Backlog.svg';
import doneIcon from '../Assets/icons_FEtask/Done.svg';
import cancelledIcon from '../Assets/icons_FEtask/Cancelled.svg';
import todoIcon from '../Assets/icons_FEtask/To-do.svg';

const Card = ({ ticket, grouping, ordering }) => {
    const getPriorityIcon = (priority) => {
        switch (priority) {
            case 4:
                return urgentPriorityIcon;
            case 3:
                return highPriorityIcon;
            case 2:
                return mediumPriorityIcon;
            case 1:
                return lowPriorityIcon;
            default:
                return noPriorityIcon;
        }
    };

    const getStatusIcon = (status) => {
        switch (status) {
            case 'In progress':
                return inProgressIcon;
            case 'Backlog':
                return backlogIcon;
            case 'Done':
                return doneIcon;
            case 'Cancelled':
                return cancelledIcon;
            case 'Todo':
                return todoIcon;
            default:
                return null;
        }
    };

    return (
        <div className="card">
            <div className="card-header">
                <span>{ticket.id}</span>
            </div>
            <div className='title'>
            {grouping !== 'Status' && (
                <img src={getStatusIcon(ticket.status)} alt="Priority Icon" className="priority-icon" />
            )}

            <h3>{ticket.title}</h3>
            </div>
            
            <div className="card-footer">
                <div className='center'>
                
                {grouping === 'Priority'  ? null
    
 : (<div className='footer-border'><img src={getPriorityIcon(ticket.priority)} alt="Priority Icon" className="priority-icon" /></div>)}

                <div className='footer-border'>
                    <div class="circle"></div>
                <span>{ticket.tag[0]}</span>
                </div>
                </div>    
            </div>
        </div>
    );
};

export default Card;
