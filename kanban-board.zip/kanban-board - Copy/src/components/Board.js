import React, { useEffect, useState } from 'react';
import './Board.css';
import Column from './Column';
import axios from 'axios';
import Down from '../Assets/icons_FEtask/down.svg'
import Display from '../Assets/icons_FEtask/Display.svg'
const API_URL = 'https://api.quicksell.co/v1/internal/frontend-assignment';

const Board = () => {
    const [tickets, setTickets] = useState([]);
    const [grouping, setGrouping] = useState(() => localStorage.getItem('savedGrouping') || 'Status');
    const [ordering, setOrdering] = useState(() => localStorage.getItem('savedOrdering') || 'Priority');
    const [dropdownOpen, setDropdownOpen] = useState(false); 

    useEffect(() => {
        axios.get(API_URL).then(response => {
            setTickets(response.data.tickets);
            console.log(tickets)
        });
    }, []);
    useEffect(() => {
        localStorage.setItem('savedGrouping', grouping);
    }, [grouping]);

    // Save the ordering state to localStorage whenever it changes
    useEffect(() => {
        localStorage.setItem('savedOrdering', ordering);
    }, [ordering]);
    const groupTickets = () => {
        const grouped = {};
        tickets.forEach(ticket => {
            const key = grouping === 'User' ? ticket.userId : grouping === 'Priority' ? ticket.priority : ticket.status;
            if (!grouped[key]) grouped[key] = [];
            grouped[key].push(ticket);
        });

        if (ordering === 'Priority') {
            for (let key in grouped) {
                grouped[key].sort((a, b) => b.priority - a.priority);
            }
        } else if (ordering === 'Title') {
            for (let key in grouped) {
                grouped[key].sort((a, b) => a.title.localeCompare(b.title));
            }
        }

        return grouped;
    };

    const handleGroupChange=(event)=>{
        const val=event.target.value;
        setGrouping(val);
    }
    const handleOrderChange=(event)=>{
        const val=event.target.value;
        setOrdering(val);
    }
    const groupedTickets = groupTickets();

    const toggleDropdown = () => {
        setDropdownOpen(!dropdownOpen);
    };

    const handleGroupingChange = (value) => {
        setGrouping(value);
    };

    const handleOrderingChange = (value) => {
        setOrdering(value);
    };

    return (
        <div className="board">
            <div className="controls">
                <div className='display-field' onClick={toggleDropdown}>
                <img src={Display} alt="" />
                <h>
                    Display
                </h>
                <img src={Down} alt=""/>
                
                </div>
                {dropdownOpen && (
                    <div className="dropdown-menu">
                        <div className="dropdown-item">
                            <div className='selected'>
                                <span>Grouping</span>
            
                            <select onChange={handleGroupChange} value={grouping}>
                                <option >Status</option>
                                <option >User</option>
                                <option onClick={() => handleGroupingChange('Priority')}>Priority</option>
                            </select>
                     
                            </div>
                        </div>
                        <div className="dropdown-item">
                            <div className='selected'>
                                <span>Ordering</span>


                                <select onChange={handleOrderChange} value={ordering}>
                                <option >Priority</option>
                                <option >Title</option>
                            </select>
                            </div>
                        </div>
                    </div>
                )}
            </div>
            <div className="columns">
                {Object.keys(groupedTickets).map((key) => (
                    <Column key={key} title={key} tickets={groupedTickets[key]} grouping={grouping} ordering={ordering} />
                ))}
            </div>
        </div>
    );
};

export default Board;
