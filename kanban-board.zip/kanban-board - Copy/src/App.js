import './App.css';
import React, { useState } from 'react';
import Board from './components/Board';

function App() {
    return (
        <div className="App">
            <h1>Kanban Board</h1>
            <Board />
        </div>
    );
}

export default App;
